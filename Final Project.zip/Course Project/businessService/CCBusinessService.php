<?php
/**
 * Created by PhpStorm.
 * User: tycru
 * Date: 5/17/2019
 * Time: 6:04 PM
 */

class CCBusinessService{

    private $owner = "";
    private $cardNumber = "";
    private $cvv ="";
    private $expMonth = "";
    private $expYear = "";

    function  __construct($owner, $cardNumber, $cvv, $expMonth, $expYear){
        $this->owner = $owner;
        $this->cardNumber = $cardNumber;
        $this->cvv = $cvv;
        $this->expMonth = $expMonth;
        $this->expYear = $expYear;
    }

    function authenticate(){
        /////////Normally this would access DAO to verify
        if($this->owner == "John Q Public" && $this->cardNumber == "4111 1111 1111 1111" && $this->cvv == 219 && $this->expMonth == 04 && $this->expYear == 20){
            return true;
        }
        else{
            return false;
        }
    }
}