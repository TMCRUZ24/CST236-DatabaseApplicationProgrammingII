<?php
/**
 * User:  Tyson Cruz
 * Date:  5/19/2019
 * Class: CST236 - Database Programming II
 * Prof:  Brandon Bass
 */

class OrdersBusinessService{

    function makeNew($order){
        $dbService = new OrderDataService();
        return $dbService->createNew($order);
    }

    function getAllOrders(){
        $dbService = new OrderDataService();
        $orders = $dbService->getAllOrders();

        return $orders;
    }

    function deleteItem($id){
        $dbService = new OrderDataService();

        return $dbService->deleteItem($id);
    }

    function findByID($id){

    }

    function updateOne($id, $order){

    }

    function getOrderDetails($id){

    }

    function checkout($order, $cart){
        //creates a new line in the orders table. This will rely on the createNew function in OrderDataService.
        //create multiple lines in the orders details table. Relies on the addDetailsLine in OrderDataService.
        //ensure that the transaction is atomic.
        $db = db_connect();
        $db->autocommit(FALSE);
        $db->begin_transaction();

        //Create new order
        $dbService = new OrderDataService();
        $productBS = new ProductBusinessService();
        $order_id = $order->getId();

        foreach ($cart->getItems() as $product_id=>$qty) {
            $product = $productBS->findByProductID($product_id);
            $lineDetail = new orderDetails(1, $order_id, $product->getProdID(), $qty, $product->getPrice(), $product->getDescription());

            $dbService->addDetailsLine($order_id, $lineDetail);

        }

    }

    function getOrdersBetweenDates($date1, $date2){
        $dbService = new OrderDataService();
        $orders = $dbService->getOrdersBetweenDates($date1, $date2);

        return $orders;
    }

    function getProductsOrderedBetweenDates($date1, $date2){
        $dbService = new OrderDataService();
        $products = $dbService->getProductsOrderedBetweenDates($date1, $date2);

        return $products;
    }

}