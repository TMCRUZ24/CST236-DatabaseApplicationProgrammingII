<?php
/**
 * User:  Tyson Cruz
 * Date:  5/12/2019
 * Class: CST236 - Database Programming II
 * Prof:  Brandon Bass
 */


class UserBusinessService{

    function findByFirstName($name){
        $persons = Array();
        $service = new UserDataService();
        $persons = $service->findByFirstName($name);
        return $persons;
    }

    function findByLastName($lastName){
        $persons = Array();
        $service = new UserDataService();
        $persons = $service->findByLastName($lastName);
        return $persons;
    }

    function findByUserName($userName){
        $persons = Array();
        $service = new UserDataService();
        $persons = $service->findByUserName($userName);
        return $persons;
    }

    function findByID($id){
        $persons = Array();
        $service = new UserDataService();
        $persons = $service->findByUserID($id);
        return $persons;
    }

    function editUser($id){
        //$persons = Array();
        $service = new UserDataService();
        $persons = $service->findByUserID($id);
        return $persons;
    }

    function makeNew($user){
        $dbService = new UserDataService();
        return $dbService->makeNew($user);
    }

    function showAll(){
        $persons = Array();
        $service = new UserDataService();
        $persons = $service->showAll();
        return $persons;
    }

    function deleteUser($id){
        $dbService = new UserDataService();
        return $dbService->deleteUser($id);
    }

    function getRole($username){
        $dbService = new UserDataService();
        return $dbService->getUserRole($username);
    }


}