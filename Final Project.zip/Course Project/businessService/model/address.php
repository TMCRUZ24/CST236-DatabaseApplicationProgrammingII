<?php
/**
 * Created by PhpStorm.
 * User: tycru
 * Date: 5/3/2019
 * Time: 9:42 PM
 */

class address{

    private $id;
    private $addressType;
    private $isDefault;
    private $userID;
    private $street;
    private $city;
    private $state;
    private $postalCode;

    function __construct($id, $addressType, $isDefault, $userID, $street, $city, $state, $postalCode){
        $this->id = $id;
        $this->addressType = $addressType;
        $this->isDefault = $isDefault;
        $this->userID = $userID;
        $this->street = $street;
        $this->city = $city;
        $this->state = $state;
        $this->postalCode = $postalCode;
    }

/**
 * @return mixed
 */
public function getId()
{
    return $this->id;
}/**
 * @param mixed $id
 */
public function setId($id)
{
    $this->id = $id;
}/**
 * @return mixed
 */
public function getAddressType()
{
    return $this->addressType;
}/**
 * @param mixed $addressType
 */
public function setAddressType($addressType)
{
    $this->addressType = $addressType;
}/**
 * @return mixed
 */
public function getisDefault()
{
    return $this->isDefault;
}/**
 * @param mixed $isDefault
 */
public function setIsDefault($isDefault)
{
    $this->isDefault = $isDefault;
}/**
 * @return mixed
 */
public function getUserID()
{
    return $this->userID;
}/**
 * @param mixed $userID
 */
public function setUserID($userID)
{
    $this->userID = $userID;
}/**
 * @return mixed
 */
public function getStreet()
{
    return $this->street;
}/**
 * @param mixed $street
 */
public function setStreet($street)
{
    $this->street = $street;
}/**
 * @return mixed
 */
public function getCity()
{
    return $this->city;
}/**
 * @param mixed $city
 */
public function setCity($city)
{
    $this->city = $city;
}/**
 * @return mixed
 */
public function getState()
{
    return $this->state;
}/**
 * @param mixed $state
 */
public function setState($state)
{
    $this->state = $state;
}/**
 * @return mixed
 */
public function getPostalCode()
{
    return $this->postalCode;
}/**
 * @param mixed $postalCode
 */
public function setPostalCode($postalCode)
{
    $this->postalCode = $postalCode;
}




}