<?php
/**
 * Created by PhpStorm.
 * User: tycru
 * Date: 5/3/2019
 * Time: 9:48 PM
 */

class product{

    private $prodID;
    private $prodName;
    private $price;
    private $description;

    function __construct($prodID, $prodName, $price, $description){
        $this->prodID = $prodID;
        $this->prodName = $prodName;
        $this->price = $price;
        $this->description = $description;
    }

    /**
     * @return mixed
     */
    public function getProdID()
    {
        return $this->prodID;
    }

    /**
     * @param mixed $prodID
     */
    public function setProdID($prodID)
    {
        $this->prodID = $prodID;
    }

    /**
     * @return mixed
     */
    public function getProdName()
    {
        return $this->prodName;
    }

    /**
     * @param mixed $prodName
     */
    public function setProdName($prodName)
    {
        $this->prodName = $prodName;
    }

    /**
     * @return mixed
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     * @param mixed $price
     */
    public function setPrice($price)
    {
        $this->price = $price;
    }

    /**
     * @return mixed
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * @param mixed $description
     */
    public function setDescription($description)
    {
        $this->description = $description;
    }



}