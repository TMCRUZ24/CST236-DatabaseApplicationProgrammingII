<?php
/**
 * User:  Tyson Cruz
 * Date:  5/14/2019
 * Class: CST236 - Database Programming II
 * Prof:  Brandon Bass
 */

class cart{

    private $userID;
    private $items = array(); //associative array (prod_id=>qty, prod_id=>qty, prod_id=>qty)
    private $subtotals = array(); //associative array (prod_id=>cost, prod_id=>cost, prod_id=>cost)
    private $total_price;

    function __construct($userID){
        $this->userID = $userID;
        $this->items = array();
        $this->subtotals = array();
        $this->total_price = 0;
    }

    function addItem($prodID){
        if(array_key_exists($prodID, $this->items)){
            $this->items[$prodID] += 1;
        }
        else{
            $this->items = $this->items + array($prodID => 1);
        }
    }

    function updateQty($prodID, $newQTY){
        if(array_key_exists($prodID, $this->items)){
            $this->items[$prodID] = $newQTY;
        }
        else{
            $this->items = $this->items + array($prodID => $newQTY);
        }

        if($this->items[$prodID] == 0){
            unset($this->items[$prodID]);
        }
    }

    function calcTotal(){
        $productBS = new ProductBusinessService();
        $subtotals_array = array();
        $this->total_price = 0;

        foreach($this->items as $item=>$qty){
            $product = $productBS->findByProductID($item);
            $product_subtotal = $product->getPrice() * $qty;
            $subtotals_array = $subtotals_array + array($item=>$product_subtotal);
            $this->total_price = $this->total_price + $product_subtotal;
        }

        $this->subtotals = $subtotals_array;
    }

    /**
     * @return mixed
     */
    public function getUserID()
    {
        return $this->userID;
    }

    /**
     * @param mixed $userID
     */
    public function setUserID($userID)
    {
        $this->userID = $userID;
    }

    /**
     * @return array
     */
    public function getItems()
    {
        return $this->items;
    }

    /**
     * @param array $items
     */
    public function setItems($items)
    {
        $this->items = $items;
    }

    /**
     * @return array
     */
    public function getSubtotals()
    {
        return $this->subtotals;
    }

    /**
     * @param array $subtotals
     */
    public function setSubtotals($subtotals)
    {
        $this->subtotals = $subtotals;
    }

    /**
     * @return int
     */
    public function getTotalPrice()
    {
        return $this->total_price;
    }

    /**
     * @param int $total_price
     */
    public function setTotalPrice($total_price)
    {
        $this->total_price = $total_price;
    }



}