<?php
/**
 * Created by PhpStorm.
 * User: tycru
 * Date: 5/14/2019
 * Time: 7:11 PM
 */

require_once "../../initialize.php";

$c = new cart(1);

$bs = new ProductBusinessService();

$prod1 = $bs ->findByProductID(11);
$prod2 = $bs ->findByProductID(15);
$prod3 = $bs ->findByProductID(5);

echo "<pre>";
print_r($prod1);
echo "</pre>";

echo "<pre>";
print_r($prod2);
echo "</pre>";

echo "<pre>";
print_r($prod3);
echo "</pre>";

$c->addItem(11);
$c->addItem(15);
$c->addItem(5);
$c->addItem(5);
$c->addItem(5);
$c->addItem(5);

echo "<pre>";
print_r($c);
echo "</pre>";

$c->updateQty(11, 13);

echo "<pre>";
print_r($c);
echo "</pre>";
$c->updateQty(15, 0);

echo "<pre>";
print_r($c);
echo "</pre>";

$c->calcTotal();

echo "<pre>";
print_r($c);
echo "</pre>";