<?php
/**
 * User:  Tyson Cruz
 * Date:  5/05/2019
 * Class: CST236 - Database Programming II
 * Prof:  Brandon Bass
 */

class ProductBusinessService{

    function findByProductID($id){
        $products = Array();
        $service = new ProductDataService();
        $products = $service->findByProductID($id);
        return $products;
    }

    //function used to search for product by name
    function findByProductName($productName){
        $products = Array();
        $service = new ProductDataService();
        $products = $service->findByProductName($productName);
        return $products;
    }

    //function used to search for product by price
    function findByProductPrice($productPrice){
        $products = Array();
        $service = new ProductDataService();
        $products = $service->findByProductPrice($productPrice);
        return $products;
    }

    function showAll(){
        $products = Array();
        $service = new ProductDataService();
        $products = $service->showAll();
        return $products;
    }

    function makeNew($product){
        $dbService = new ProductDataService();
        return $dbService->makeNew($product);
    }

    function editProduct($id){
        $products = Array();
        $service = new ProductDataService();
        $products = $service->findByProductID($id);
        return $products;
    }

    function deleteProduct($id){
        $dbService = new ProductDataService();
        return $dbService->deleteProduct($id);
    }
}