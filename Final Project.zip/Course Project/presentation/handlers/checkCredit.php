<?php
/**
 * User:  Tyson Cruz
 * Date:  5/17/2019
 * Class: CST236 - Database Programming II
 * Prof:  Brandon Bass
 */

require_once "../../initialize.php";
require_once "../../header.php";

$owner = $_POST['cardName'];
$number = $_POST['cardNumber'];
$cvv = $_POST['cvv'];
$month = $_POST['expMonth'];
$year = $_POST['expYear'];

$ccService = new CCBusinessService($owner, $number, $cvv, $month, $year);
$productBS = new ProductBusinessService();

if($ccService->authenticate()){
    //echo "<h5>Authenticated!</h5>";

    if(isset($_SESSION['cart'])){
        $c = $_SESSION['cart'];
    }
    else{
        echo "There's nothing in your cart<br>";
    }

    if(isset($_SESSION['idUser'])){
        $idUser = $_SESSION['idUser'];
    }
    else{
        echo "You are not logged in.<br>";
        exit();
    }

    if($c->getUserID() != $idUser){
        echo "Cart does not belong to you";
        exit();
    }

    $totalPrice = 0;
    //$user = $userBS->findByID($idUser);
    echo "<h1>Order Complete!</h1>";
//echo "<h4>Review Order for: <span class=\"badge badge-info\">".$user->getFirstName();
    echo "</span>";
    echo "</h4>";

    setlocale(LC_MONETARY, 'en_US.UTF-8');

    echo "<table class='table table-striped'>";
    echo "<thead>";
    echo "<tr>";
    echo "<th scope='col'>Product ID</th>";
    echo "<th scope='col'>Product Name</th>";
    echo "<th scope='col'>Quantity</th>";
    echo "<th scope='col'>Price</th>";
    echo "<th scope='col'>Line Subtotal</th>";
    echo "</tr>";
    echo "</thead>";
    echo "<tbody>";
    foreach ($c->getItems() as $product_id=>$qty) {
        $product = $productBS->findByProductID($product_id);
        echo "<tr>";
        echo "<td>" . $product->getProdID() . "</td>";
        echo "<td>" . $product->getProdName() . "</td>";
        echo "<td>" . $qty. "</td>";
        echo "<td>" . $product->getPrice() . "</td>";
        echo "<td>" . $qty * $product->getPrice() . "</td>";
        $totalPrice += $qty * $product->getPrice();
        echo "</tr>";
    }
    echo "</tbody>";
    echo "</table>";
    echo "<h2>Total Price: $".$totalPrice."</h2>";

    ////////////////////////////////////////////////////////////////////////////////////////////

    $db = db_connect();
    $order = new order(1, "05/16/2019", $idUser, $idUser, $totalPrice);
    $OrdersBS = new OrdersBusinessService();
    $orderID = $OrdersBS->makeNew($order);
    $OrdersBS->checkout($order, $c);

    //echo "<pre>";/////////////////
    //print_r($order);//////////////
    //echo "</pre>";////////////////

    echo "<h2>Order Number: ".$orderID."</h2>";
    echo "<h4><a href=\"../views/welcome.php\" class=\"badge badge-info\">Continue Shopping</a></h4>";




}
else{
    echo "<h5>Failed to authenticate</h5>";
    exit();
}