<?php
/**
 * User:  Tyson Cruz
 * Date:  5/05/2019
 * Class: CST236 - Database Programming II
 * Prof:  Brandon Bass
 */

require_once "../../initialize.php";
require_once "../../header.php";

$searchPhrase = $_GET['productname'];
$search = new ProductBusinessService();
$products = $search->findByProductName($searchPhrase);
?>

<h2>Search Results</h2>
<br>
<h4>Here's what we found...</h4>

<?php
if($search){
    require_once "../views/__displayProducts.php";
    __displayProducts($products);
}
else{
    echo "Nothing found here like that...<br>";
}