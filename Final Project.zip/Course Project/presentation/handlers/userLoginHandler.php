<?php
/**
 * Created by PhpStorm.
 * User: tycru
 * Date: 5/13/2019
 * Time: 10:44 PM
 */

require_once '../../header.php';
require_once '../../initialize.php';

//$username = $_GET['username'];
$username = '';
$password = '';
$userID = '';

$username = $_POST['username'];
$password = $_POST['password'];

$search = new UserBusinessService();
$person = $search->findByUserName($username);

if(password_verify($password, $person->getPassword())) {
    $_SESSION['username'] = $username;
    $_SESSION['idUser'] = $person->getID();
    $_SESSION['role'] = $person->getRole();
    //header("Location: ../views/adminProducts.php");//////////this one works
    //exit();
    redirect_to("../views/welcome.php");//function found in initialize.php
}
else{
    echo "<div class=\"container\">";
    echo "<h3>Incorrect Username/Password</h3><br>";
    ?>
    <a class="btn btn-dark" href="../views/index.php">Return to Login</a>
    <?php echo  "</div>";
}

