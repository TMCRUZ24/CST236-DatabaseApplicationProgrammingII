<?php
/**
 * User:  Tyson Cruz
 * Date:  5/15/2019
 * Class: CST236 - Database Programming II
 * Prof:  Brandon Bass
 */
require_once "../../initialize.php";
require_once "../../header.php";
//session_start();

$id = $_GET['id'];//product ID

if(isset($_SESSION['cart'])){
    $c = $_SESSION['cart'];
}
else{
    if(isset($_SESSION['idUser'])){
        $c = new Cart($_SESSION['idUser']);
        $_SESSION['cart'] = $c;
    }
    else{
        echo "Please login first<br>";
        exit();
    }
}

$c->addItem($id);
$c->calcTotal();

//echo "<pre>";
//print_r($_SESSION['cart']);
//echo "</pre>";

//header("Location: ../views/showCart.php");
redirect_to("../views/showCart.php");