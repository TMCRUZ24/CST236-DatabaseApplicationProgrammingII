<?php
/**
 * User:  Tyson Cruz
 * Date:  5/12/2019
 * Class: CST236 - Database Programming II
 * Prof:  Brandon Bass
 */

require_once "../../header.php";
require_once "../../initialize.php";

if(isset($_GET)){
    $id = '0';
    $name = $_GET['productname'];
    $price = $_GET['price'];
    $description = $_GET['description'];
}else{
    echo "Form is missing product information";
}

$bs = new ProductBusinessService();
$product = new product($id, $name, $price, $description);

if($bs->makeNew($product)){
    echo "Item inserted<br>";
}else{
    echo "Nothing inserted<br>";
}

echo "<a href='../views/welcome.php'>Return to main page</a>";