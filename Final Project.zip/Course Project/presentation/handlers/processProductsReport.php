<?php
/**
 * Created by PhpStorm.
 * User: tycru
 * Date: 6/2/2019
 * Time: 5:41 PM
 */

require_once "../../initialize.php";
require_once "../../header.php";

$date1 = $_GET['startdate'];
$date2 = $_GET['enddate'];

$orderbs = new OrdersBusinessService();
$productbs = new ProductBusinessService();

$products = $orderbs->getProductsOrderedBetweenDates($date1, $date2);

if($products == null){
    echo "Sorry. No orders found within this date range";
    echo "<br>";
    echo "Start date: ".$date1;
    echo "<br>";
    echo "End date: ".$date2;
    exit;
}

include '../views/__displaySalesReportTable.php';