<?php
/**
 * Created by PhpStorm.
 * User: tycru
 * Date: 5/30/2019
 * Time: 11:48 AM
 */

require_once "../../initialize.php";
require_once "../../header.php";

$date1 = $_GET['startdate'];
$date2 = $_GET['enddate'];

$orderbs = new OrdersBusinessService();
$userbs = new UserBusinessService();

$orders = $orderbs->getOrdersBetweenDates($date1, $date2);

if($orders == null){
    echo "Sorry. No orders found within this date range";
    echo "<br>";
    echo $date1;
    echo "<br>";
    echo $date2;
    exit;
}

include '../views/__displayOrdersReportsTable.php';