<?php
/**
 * Created by PhpStorm.
 * User: tycru
 * Date: 5/4/2019
 * Time: 4:54 PM
 */

require_once "../../initialize.php";

$searchPhrase = $_GET['name'];

$search = new UserBusinessService();

$search->findByFirstName($searchPhrase);






