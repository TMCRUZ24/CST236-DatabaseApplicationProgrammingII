<?php
/**
 * User:  Tyson Cruz
 * Date:  5/16/2019
 * Class: CST236 - Database Programming II
 * Prof:  Brandon Bass
 */

require_once "../../initialize.php";
require_once "../../header.php";

$id = $_GET['id'];
$qty = $_GET['qty'];
$c = $_SESSION['cart'];

$c->updateQty($id, $qty);
$c->calcTotal();

header("Location: ../views/showCart.php");
//redirect_to("showCart.php");



