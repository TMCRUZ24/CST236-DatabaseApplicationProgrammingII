<?php
/**
 * User:  Tyson Cruz
 * Date:  5/13/2019
 * Class: CST236 - Database Programming II
 * Prof:  Brandon Bass
 */

require_once "../../initialize.php";
require_once "../../header.php";

$id = $_GET['id'];

$bs = new UserBusinessService();
$success = $bs->deleteUser($id);

if($success){
    echo "Item was deleted.<br>";
}else{
    echo "Nothing deleted.<br>";
}