<?php
/**
 * Created by PhpStorm.
 * User: tycru
 * Date: 6/2/2019
 * Time: 4:22 PM
 */

require_once "../../initialize.php";
require_once "../../header.php";

logout_user();

unset($_SESSION['username']);
unset($_SESSION['idUser']);
unset($_SESSION['role']);

redirect_to("../views/index.php");
