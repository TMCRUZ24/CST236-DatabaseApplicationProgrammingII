<?php
/**
 * User:  Tyson Cruz
 * Date:  5/09/2019
 * Class: CST236 - Database Programming II
 * Prof:  Brandon Bass
 */

require_once "../../header.php";
require_once "../../initialize.php";

if(isset($_GET)){
    //$id = 0;
    $firstname = $_GET['firstname'];
    $lastname = $_GET['lastname'];
    $username = $_GET['username'];
    //$role = 0;
    $password = $_GET['password'];
}else{
    echo "Form is missing user information";
}

$bs = new UserBusinessService();
$user = new user(0, $firstname, $lastname, $username, $password, 0);

if($bs->makeNew($user)){
    echo "Item inserted<br>";
}else{
    echo "Nothing inserted<br>";
}

echo "<a href='../views/welcome.php'>Return to main page</a>";
