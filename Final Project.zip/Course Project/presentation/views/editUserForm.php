<?php
/**
 * User:  Tyson Cruz
 * Date:  5/13/2019
 * Class: CST236 - Database Programming II
 * Prof:  Brandon Bass
 */

require_once '../../header.php';
require_once '../../initialize.php';

require_admin_login();

$id = $_GET['id'];

$bs = new UserBusinessService();

$user = $bs->editUser($id);
?>

<div class="container">

    <h1>Update user account</h1>

    <form action="../handlers/processUpdateUser.php">
        <div class="form-group">
            <input type="hidden" class="form-control" id="userID" value="<?php echo $user->getID();?>" name="userID">
        </div>
        <div class="form-group">
            <label for="firstname">First Name: </label>
            <input type="text" class="form-control" id="firstname" value="<?php echo $user->getFirstName();?>" name = "firstname">
        </div>
        <div class="form-group">
            <label for="lastname">Last Name: </label>
            <input type="text" class="form-control" id="lastname" value="<?php echo $user->getLastName();?>" name = "lastname">
        </div>
        <div class="form-group">
            <label for="username">User Name: </label>
            <input type="text" class="form-control" id="username" value="<?php echo $user->getUsername();?>" name = "username">
        </div>
        <div class="form-group">
            <label for="role">Role: </label>
            <select class="form-control" id="role" name="role">
                <option <?php if($user->getRole() == 0){echo "selected='selected'";}?>>0</option>
                <option <?php if($user->getRole() == 1){echo "selected='selected'";}?>>1</option>
                <option <?php if($user->getRole() == 2){echo "selected='selected'";}?>>2</option>
                <option <?php if($user->getRole() == 3){echo "selected='selected'";}?>>3</option>
                <option <?php if($user->getRole() == 4){echo "selected='selected'";}?>>4</option>
            </select>
        </div>
        <div class="form-group">
            <label for="password">Password: </label>
            <input type="text" class="form-control" id="password" value="<?php echo $user->getPassword();?>" name = "password">
        </div>
        <button type="submit" class="btn btn-dark">Update</button>
    </form>

</div>