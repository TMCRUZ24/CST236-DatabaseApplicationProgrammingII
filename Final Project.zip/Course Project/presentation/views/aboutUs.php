<?php
/**
 * Created by PhpStorm.
 * User: tycru
 * Date: 6/2/2019
 * Time: 10:41 PM
 */

require_once "../../initialize.php";
require_once "../../header.php";

?>

<div class="container">
<h4><br>
This web application is used as an eCommerce platform.
   It starts at a login screen that allows the user to login to his or her account,
   or a link to register a new user. Once logged in, a user can browse for products,
   add them to their cart, and go through the checkout process.
</h4>
    <span class="badge badge-info">
    <h4><a href=\"../handlers/productSearchHandler.php\" class=\"badge badge-info\">Continue Shopping</a></h4>
    </span>
</div>