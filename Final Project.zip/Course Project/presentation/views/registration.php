<?php
/**
 * Created by PhpStorm.
 * User: Tyson Cruz
 * Date: 4/24/2019
 * Time: 5:29 PM
 */

require_once "../../header.php";
require_once "../../initialize.php";
?>

<!--<head>
    <link rel="stylesheet" type="text/css" href="../css/forms.css">
</head>
-->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Registration</title>
</head>

<body>
<div class="container">

    <h1>Create a new user account</h1>

    <h3>User Registration</h3>
    <br>
    <form action="../handlers/processNewUser.php">
        <div class="form-group">
            <label for="firstname">First Name: </label>
            <input type="text" class="form-control" id="firstname" name = "firstname">
        </div>
        <div class="form-group">
            <label for="lastname">Last Name: </label>
            <input type="text" class="form-control" id="lastname" name = "lastname">
        </div>
        <div class="form-group">
            <label for="username">User Name: </label>
            <input type="text" class="form-control" id="username" name = "username">
        </div>
        <div class="form-group">
            <label for="password">Password: </label>
            <input type="password" class="form-control" id="password" name = "password">
        </div>
        <button type="submit" class="btn btn-dark">Register</button>
    </form>
</div>

</body>
</html>
