<?php
/**
 * Created by PhpStorm.
 * User: tycru
 * Date: 6/2/2019
 * Time: 6:18 PM
 */

?>

    <script
        src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha256-3edrmyuQ0w65f8gfBsqowzjJe2iM6n0nKciPUp8y+7E="
        crossorigin="anonymous">
    </script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

<script>
    $(document).ready( function () {
        $('#myTable').DataTable();
    } );
</script>

<!--
    <link rel="stylesheet" type="text/css" href="../css/forms.css">
-->
<div class="container">
<h1>Sales Report:</h1>
<h3>Start Date: <?php echo $date1?> : End Date: <?php echo $date2?></h3>
<br>
<table id="myTable">
    <thead>
        <th>Product ID: </th>
        <th>Product: </th>
        <th>Quantity: </th>
        <th>Sales: </th>
    </thead>

    <?php
    $salesTotal = 0;

    //setlocale(LC_MONETARY, 'en_US.UTF-8');
    foreach($products as $product){
        $product = $productbs->findByProductID($product['prodID']);
        echo "<tr>";
            echo "<td>".$product['prodID']."</td>";
            echo "<td>".$product['prodName']."</td>";
            echo "<td>".$product['quantity']."</td>";
            echo "<td>$"./*money_format('%.2n', */($product['price'] * $product['quantity'])/*)*/."</td>";
            $salesTotal += ($product['price'] * $product['quantity']);
        echo "</tr>";
    }
    ?>
</table>
</div>