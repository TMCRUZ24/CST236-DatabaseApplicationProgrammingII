<?php
/**
 * Created by PhpStorm.
 * User: tycru
 * Date: 5/30/2019
 * Time: 11:10 AM
 */
require_once "../../initialize.php";
require_once "../../header.php";

require_admin_login();

?>

<!--<head>
    <link rel="stylesheet" type="text/css" href="../css/forms.css">
</head>
-->

<div class="container">
    <br>
    <h2>View All Orders</h2>
    <div class="centerHalf">
        <form class="inputForm" action="../handlers/processOrdersReport.php">
            <div class="form-group">
                <label for="startdate">Start Date:</label>
                <input class="form-control" name="startdate" type="date">
            </div>
            <div class="form-group">
                <label for="enddate">End Date:</label>
                <input class="form-control" name="enddate" type="date">
            </div>
            <a class="btn btn-light" href="welcome.php">Cancel</a>
            <input class="btn btn-primary" type="submit" value="Generate Report">
        </form>
    </div>

    <br>

    <h2>Generate Sales Report</h2>
    <div class="centerHalf">
        <form class="inputForm" action="../handlers/processProductsReport.php">
            <div class="form-group">
                <label for="startdate">Start Date:</label>
                <input class="form-control" name="startdate" type="date">
            </div>
            <div class="form-group">
                <label for="enddate">End Date:</label>
                <input class="form-control" name="enddate" type="date">
            </div>
            <a class="btn btn-light" href="welcome.php">Cancel</a>
            <input class="btn btn-primary" type="submit" value="Generate Report">
        </form>
    </div>
</div>