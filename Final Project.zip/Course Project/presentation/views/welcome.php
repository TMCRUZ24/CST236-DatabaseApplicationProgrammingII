<?php
/**
 * User:  Tyson Cruz
 * Date:  04/24/2019
 * Class: CST236 - Database Programming II
 * Prof:  Brandon Bass
 */
//session_start();
require_once '../../initialize.php';
require_once '../../header.php';
// Set session variables


?>

<!--<head>
    <link rel="stylesheet" type="text/css" href="../css/forms.css">
</head>
-->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome!</title>
</head>

<body>
<div class="container">
    <br>
    <form action="../handlers/productSearchHandler.php">
        <h4>Browse Products</h4>
        <div class="form-group">
            <label for="productname">Product Name: </label>
            <input type="text" class="form-control" id="productname" name = "productname">
        </div>
        <button type="submit" class="btn btn-dark">Browse</button>
    </form>
    <!------------------------------------------------ -->
    <form action="../handlers/processOrdersReport.php">
        <br>
        <h4>Search Your Orders</h4>
        <div class="form-group">
            <label for="startdate">Start Date:</label>
            <input class="form-control" name="startdate" type="date">
        </div>
        <div class="form-group">
            <label for="enddate">End Date:</label>
            <input class="form-control" name="enddate" type="date">
        </div>
        <button type="submit" class="btn btn-dark">Search</button>
    </form>
    <br>
    <h4>My Info</h4>
    <a class="btn btn-dark" href="editUserForm.php">Edit my Info</a>

    <!------------------------------------------------ -->


</div>
</body>
</html>