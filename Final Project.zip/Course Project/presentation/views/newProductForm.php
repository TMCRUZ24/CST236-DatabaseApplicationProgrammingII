<?php
/**
 * User:  Tyson Cruz
 * Date:  5/13/2019
 * Class: CST236 - Database Programming II
 * Prof:  Brandon Bass
 */

require_once "../../initialize.php";
require_once "../../header.php";

$bs = new ProductBusinessService();
$products = $bs-> showAll();

?>
<!--<head>
    <link rel="stylesheet" type="text/css" href="../css/forms.css">
</head>
-->

<div class="container">

    <h1>Create a new user product</h1>

    <form action="../handlers/processNewProduct.php">
        <div class="form-group">
            <label for="productname">Product Name: </label>
            <input type="text" class="form-control" id="productname" placeholder="Enter Product Name" name = "productname">
        </div>
        <div class="form-group">
            <label for="price">Price: </label>
            <input type="text" class="form-control" id="price" placeholder="Enter Price" name = "price">
        </div>
        <div class="form-group">
            <label for="description">Product Description: </label>
            <input type="text" class="form-control" id="description" placeholder="Enter Product Description" name = "description">
        </div>
        <button type="submit" class="btn btn-dark">Submit</button>
    </form>

</div>
