<?php
/**
 * User:  Tyson Cruz
 * Date:  5/13/2019
 * Class: CST236 - Database Programming II
 * Prof:  Brandon Bass
 */

require_once "../../initialize.php";
require_once "../../header.php";

require_admin_login();

$bs = new ProductBusinessService();

$products = $bs->showAll();

echo "<h1>All Products: </h1>";

require_once "__displayAllProducts.php";

__displayAllProducts($products);