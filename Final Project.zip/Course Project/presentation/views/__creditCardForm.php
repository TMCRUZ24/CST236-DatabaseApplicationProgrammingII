<?php
/**
 * User:  Tyson Cruz
 * Date:  5/17/2019
 * Class: CST236 - Database Programming II
 * Prof:  Brandon Bass
 */
require_once "../../initialize.php";
require_once "../../header.php";
?>

<p>
    Validate the Following Number:<br>
    John Q Public<br>
    4111 1111 1111 1111<br>
    219<br>
    April 2020<br>
</p>

<div class="container">
<form action="../handlers/checkCredit.php" method="post">
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="cardName">Name on Card</label>
            <input type="text" class="form-control" id="cardName" name="cardName">
        </div>
    </div>
    <div class="form-group">
        <label for="cardNumber">Card Number</label>
        <input type="text" class="form-control" id="cardNumber" name="cardNumber">
    </div>
    <div class="form-row">
        <div class="form-group col-md-2">
            <label for="cvv">CVV</label>
            <input type="text" class="form-control" id="cvv" name="cvv">
        </div>
        <div class="form-group col-md-4">
            <label for="expMonth">Month</label>
            <select id="expMonth" class="form-control" name="expMonth">
                <option selected>Choose...</option>
                <option value="01">January</option>
                <option value="02">February</option>
                <option value="03">March</option>
                <option value="04">April</option>
                <option value="05">May</option>
                <option value="06">June</option>
                <option value="07">July</option>
                <option value="08">August</option>
                <option value="09">September</option>
                <option value="10">October</option>
                <option value="11">November</option>
                <option value="12">December</option>
            </select>
        </div>
        <div class="form-group col-md-2">
            <label for="expYear">Year</label>
            <select id="expYear" class="form-control" name="expYear">
                <option selected>Choose...</option>
                <option value="19">2019</option>
                <option value="20">2020</option>
                <option value="21">2021</option>
                <option value="22">2022</option>
                <option value="23">2023</option>
                <option value="24">2024</option>
            </select>
        </div>
    </div>
    <button type="submit" class="btn btn-primary" id="confirm-purchase">Confirm</button>
</form>
</div>