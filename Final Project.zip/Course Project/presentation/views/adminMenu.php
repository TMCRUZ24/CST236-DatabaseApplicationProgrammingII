<?php
/**
 * Created by PhpStorm.
 * User: tycru
 * Date: 5/13/2019
 * Time: 10:55 PM
 */

require_once '../../header.php';
require_once '../../initialize.php';

echo "Welcome to the admin menu!";