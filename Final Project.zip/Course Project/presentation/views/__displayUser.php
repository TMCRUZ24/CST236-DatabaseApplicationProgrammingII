<?php
/**
 * User:  Tyson Cruz
 * Date:  5/12/2019
 * Class: CST236 - Database Programming II
 * Prof:  Brandon Bass
 */

//function used to display users in a table format
function __displayUser($users){
    if(count($users) > 0) {
        echo "<table id='displayTable'>";
        echo "<tr>";
        echo "<th>User ID</th>";
        echo "<th>First Name</th>";
        echo "<th>Last Name</th>";
        echo "</tr>";
        for ($x = 0; $x < count($users); $x++) {
            echo "<tr>";
            echo "<td>" . $users[$x]['idUser'] . "</td>";
            echo " ";
            echo "<td>" . $users[$x]['firstname'] . "</td>";
            echo " ";
            echo "<td>" . $users[$x]['lastname'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    else{
        echo "Search returned no results!";
    }
}