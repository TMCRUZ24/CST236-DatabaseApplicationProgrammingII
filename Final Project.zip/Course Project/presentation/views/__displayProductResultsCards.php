<?php
/**
 * Created by PhpStorm.
 * User: tycru
 * Date: 5/13/2019
 * Time: 1:49 PM
 */


//expects an array of $product. Display the results in a table.
?>

<!--<head>
    <link rel="stylesheet" type="text/css" href="../css/forms.css">
</head>
-->

<body>


</body>


<?php
for($x = 0; $x < count($products); $x++){



?>

<div class="col-12 col-sm-6 col-md-4 col-lg-3">
    <div class="card border-dark">
      <img class="card-img-top" src="../product_pics/<?php echo $products[$x]['PHOTO']?>" alt="Card image cap">
      <div class="card-body">
        <h5 class="card-title"><?php echo $products[$x]['prodName']?></h5>
        <h5 class="card-title"><?php echo "?".$products[$x]['price']?></h5>
        <p class="card-text"><?php echo $products[$x]['description']?></p>
          <?php setlocale(LC_MONETARY, 'en_US.UTF-8')?>
          <p class="card-text"><?php echo money_format('%.2n', $products[$x]['price'])?></p>
        <form action="../handlers/addToCart.php">
            <input type="hidden" name="id" value="<?php echo $products[$x]['prodID']?>">
            <input class="btn btn-primary" type="submit" value="Add to Cart">
        </form>
      </div>
    </div>
</div>
<?php
}

