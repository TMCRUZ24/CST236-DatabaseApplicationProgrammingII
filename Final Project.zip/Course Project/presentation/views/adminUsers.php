<?php
/**
 * User:  Tyson Cruz
 * Date:  5/12/2019
 * Class: CST236 - Database Programming II
 * Prof:  Brandon Bass
 */

require_once "../../initialize.php";
require_once "../../header.php";

require_admin_login();

$bs = new UserBusinessService();

$persons = $bs->showAll();

echo "<h1>All users: </h1>";

require_once "__displayAllUsers.php";

__displayAllUsers($persons);