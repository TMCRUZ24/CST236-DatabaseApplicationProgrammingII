<?php
/**
 * Created by PhpStorm.
 * User: tycru
 * Date: 5/13/2019
 * Time: 10:02 PM
 */

function __displayProducts($products){

    if(count($products) > 0) {
        echo "<table id='displayTable'>";
        echo "<tr>";
        echo "<th>  </th>";
        echo "<th>Product Number:</th>";
        echo "<th>Product Name:</th>";
        echo "<th>Price:</th>";
        echo "<th>Description</th>";
        echo "</tr>";
        for ($x = 0; $x < count($products); $x++) {
            echo "<tr>";
            echo "<td><form action='../handlers/addToCart.php'><input type='hidden' name='id' value=" .$products[$x]['prodID']."><input type='submit' value='Add to Cart'></form></td>";
            echo "<td>" . $products[$x]['prodID'] . "</td>";
            echo " ";
            echo "<td>" . $products[$x]['prodName'] . "</td>";
            echo " ";
            echo "<td>" . $products[$x]['price'] . "</td>";
            echo " ";
            echo "<td>" . $products[$x]['description'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    else{
        echo "Search returned no results!";
    }






/*    if(count($products) > 0) {
        echo "<table id='displayTable'>";
        echo "<tr>";
        echo "<th>Product ID</th>";
        echo "<th>Product Name</th>";
        echo "<th>Price</th>";
        echo "<th>Description</th>";
        echo "</tr>";
        for ($x = 0; $x < count($products); $x++) {
            echo "<tr>";
            echo "<td>" . $products[$x]['prodID'] . "</td>";
            echo " ";
            echo "<td>" . $products[$x]['prodName'] . "</td>";
            echo " ";
            echo "<td>" . $products[$x]['price'] . "</td>";
            echo " ";
            echo "<td>" . $products[$x]['description'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    else{
        echo "Search returned no results!";
    }
*/
}