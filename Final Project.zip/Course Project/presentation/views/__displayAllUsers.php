<?php
/**
 * User:  Tyson Cruz
 * Date:  5/12/2019
 * Class: CST236 - Database Programming II
 * Prof:  Brandon Bass
 */

//function used to display all users in a table format
function __displayAllUsers($users){
    if(count($users) > 0) {
        echo "<table id='displayTable'>";
        echo "<tr>";
        echo "<th>Edit</th>";
        echo "<th>Delete</th>";
        echo "<th>User ID</th>";
        echo "<th>First Name</th>";
        echo "<th>Last Name</th>";
        echo "<th>Role</th>";
        echo "<th>Username</th>";
        echo "<th>Password</th>";
        echo "</tr>";
        for ($x = 0; $x < count($users); $x++) {
            echo "<tr>";
            echo "<td><form action='editUserForm.php'><input type='hidden' name='id' value=".$users[$x]['idUser']."><input type='submit' value='Edit'></form></td>";
            echo "<td><form action='../handlers/deleteUser.php'><input type='hidden' name='id' value=" .$users[$x]['idUser']."><input type='submit' value='Delete'></form></td>";
            echo "<td>" . $users[$x]['idUser'] . "</td>";
            echo " ";
            echo "<td>" . $users[$x]['firstname'] . "</td>";
            echo " ";
            echo "<td>" . $users[$x]['lastname'] . "</td>";
            echo " ";
            echo "<td>" . $users[$x]['role'] . "</td>";
            echo " ";
            echo "<td>" . $users[$x]['username'] . "</td>";
            echo " ";
            echo "<td>" . $users[$x]['hashed_password'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    else{
        echo "Search returned no results!";
    }
}