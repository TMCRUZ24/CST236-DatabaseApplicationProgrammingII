<?php
/**
 * Created by PhpStorm.
 * User: tycru
 * Date: 5/30/2019
 * Time: 11:51 AM
 */

?>

    <script
        src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha256-3edrmyuQ0w65f8gfBsqowzjJe2iM6n0nKciPUp8y+7E="
        crossorigin="anonymous">
    </script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

<script>
    $(document).ready( function () {
        $('#myTable').DataTable();
    } );
</script>

<!--
    <link rel="stylesheet" type="text/css" href="../css/forms.css">
-->
<div class="container">
<h1>Orders Report:</h1>
<h3>Start Date: <?php echo $date1?> : End Date: <?php echo $date2?></h3>
<br>
<table id="myTable">
    <thead>
        <th>Order ID: </th>
        <th>Date: </th>
        <th>User ID / Name: </th>
        <th>Total Price: </th>
    </thead>

    <?php
    $reportTotal = 0;

    //setlocale(LC_MONETARY, 'en_US.UTF-8');
    foreach($orders as $order){
        $user = $userbs->findByID($order['orders_id']);
        echo "<tr>";
            echo "<td>".$order['orders_id']."</td>";
            echo "<td><a href='../views/showOneOrder.php?id=".$order['orders_id']."'>".$order['date']."</a></td>";
            echo "<td>".$order['users_id']. "/" .$user->getUsername()."</td>";
            echo "<td>$"./*money_format('%.2n', */$order['totalPrice']/*)*/."</td>";
            $reportTotal += $order['totalPrice'];
        echo "</tr>";
    }

echo "</table>";
echo "<h3>Total Sales $".$reportTotal."</h3>";
    ?>
</div>