<?php
/**
 * User:  Tyson Cruz
 * Date:  5/13/2019
 * Class: CST236 - Database Programming II
 * Prof:  Brandon Bass
 */

require_once '../../header.php';
require_admin_login();
require_once '../../initialize.php';


$id = $_GET['id'];

$bs = new ProductBusinessService();

$product = $bs->editProduct($id);
?>

<div class="container">
    <h1>Update Product info</h1>

    <form action="../handlers/processUpdateProduct.php">
        <div class="form-group">
            <input type="hidden" class="form-control" id="prodID" value="<?php echo $product->getProdID();?>" name="prodID">
        </div>
        <div class="form-group">
            <label for="productname">Product Name: </label>
            <input type="text" class="form-control" id="productname" value="<?php echo $product->getProdName();?>" name = "productname">
        </div>
        <div class="form-group">
            <label for="price">Price: </label>
            <input type="text" class="form-control" id="price" value="<?php echo $product->getPrice();?>" name = "price">
        </div>
        <div class="form-group">
            <label for="description">Description: </label>
            <input type="text" class="form-control" id="description" value="<?php echo $product->getDescription();?>" name = "description">
        </div>
        <button type="submit" class="btn btn-dark">Update</button>
    </form>
</div>