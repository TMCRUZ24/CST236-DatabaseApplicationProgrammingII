<?php
/**
 * User:  Tyson Cruz
 * Date:  5/05/2019
 * Class: CST236 - Database Programming II
 * Prof:  Brandon Bass
 */
require_once '../../initialize.php';
require_once '../../header.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
</head>

<body>
<div class="container">
    <br>
    <h3>User Login</h3>
    <form action="../handlers/userLoginHandler.php" method="post">
        <div class="form-group">
            <label for="username">User Name: </label>
            <input type="text" class="form-control" id="username" name = "username">
        </div>
        <div class="form-group">
            <label for="password">Password: </label>
            <input type="password" class="form-control" id="password" name = "password">
        </div>
        <button type="submit" class="btn btn-dark">Login</button>
    </form>
    <br><br>
    <form action="../handlers/productSearchHandler.php">
        <h3>Browse Products</h3>
        <div class="form-group">
            <label for="productname">Product Name: </label>
            <input type="text" class="form-control" id="productname" name = "productname">
        </div>
        <button type="submit" class="btn btn-dark">Browse</button>
    </form>
    <br><br>
    <form action="registration.php">
        <h3>For New Users</h3>
        <button type="submit" class="btn btn-dark">Register</button>
        <br><br>
    </form>
</div>
</body>
</html>
