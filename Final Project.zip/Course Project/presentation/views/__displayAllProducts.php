<?php
/**
 * User:  Tyson Cruz
 * Date:  5/05/2019
 * Class: CST236 - Database Programming II
 * Prof:  Brandon Bass
 */


/*<!--<head>
    <link rel="stylesheet" type="text/css" href="../css/forms.css">
</head>
-->
*/

//function used to display all products in a table format
function __displayAllProducts($products){
    if(count($products) > 0) {
        echo "<table id='displayTable'>";
        echo "<tr>";
        echo "<th>  </th>";
        echo "<th>  </th>";
        echo "<th>Product Number:</th>";
        echo "<th>Product Name:</th>";
        echo "<th>Price:</th>";
        echo "<th>Description:</th>";
        echo "</tr>";
        for ($x = 0; $x < count($products); $x++) {
            echo "<tr>";
            echo "<td><form action='editProductForm.php'><input type='hidden' name='id' value=".$products[$x]['prodID']."><input type='submit' value='Edit'></form></td>";
            echo "<td><form action='../handlers/deleteProduct.php'><input type='hidden' name='id' value=" .$products[$x]['prodID']."><input type='submit' value='Delete'></form></td>";
            echo "<td>" . $products[$x]['prodID'] . "</td>";
            echo " ";
            echo "<td>" . $products[$x]['prodName'] . "</td>";
            echo " ";
            echo "<td>" . $products[$x]['price'] . "</td>";
            echo " ";
            echo "<td>" . $products[$x]['description'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    else{
        echo "Search returned no results!";
    }
}