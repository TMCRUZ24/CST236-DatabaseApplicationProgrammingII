<?php
/**
 * User:  Tyson Cruz
 * Date:  5/05/2019
 * Class: CST236 - Database Programming II
 * Prof:  Brandon Bass
 */

require_once "database/database.php";
require_once "businessService/ProductBusinessService.php";
require_once "database/ProductDataService.php";
require_once "businessService/UserBusinessService.php";
require_once "database/UserDataService.php";
require_once "businessService/model/user.php";
require_once "businessService/model/product.php";
require_once "businessService/model/cart.php";
require_once "businessService/CCBusinessService.php";
require_once "businessService/model/order.php";
require_once "businessService/model/orderDetails.php";
require_once "businessService/OrdersBusinessService.php";
require_once "database/OrderDataService.php";

function redirect_to($location){
    header("Location: ".$location);
    exit();
}

function is_logged_in(){
    return isset($_SESSION['role']);
}

function is_admin(){
    if(($_SESSION['role']) == 1){
        return true;
    }
    else{
        return false;
    }
}

function require_admin_login(){
    if(!is_admin()){
        redirect_to("index.php");
    }
}

function logout_user(){
    unset($_SESSION['username']);
    unset($_SESSION['idUser']);
    unset($_SESSION['role']);
    session_destroy();

    return true;
}
