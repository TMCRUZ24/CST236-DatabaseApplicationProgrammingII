<?php
/**
 * User:  Tyson Cruz
 * Date:  5/05/2019
 * Class: CST236 - Database Programming II
 * Prof:  Brandon Bass
 */

class OrderDataService{

    function deleteItem($id){

    }/////////TO-DO

    function findByID($id){

    }/////////TO-DO

    function getAllOrders(){

    }/////////TO-DO

    function updateOne($id, $order){

    }/////////TO-DO

    function createNew($order){

        $db = db_connect();
        $sql = $db->prepare("INSERT INTO orders (date, users_id, addresses_id, totalPrice) VALUES (?, ?, ?, ?)");

        if(!$sql){
            echo "Something wrong in the binding process. SQL Error";
            exit();
        }

        //$order_id = $order->getId();
        $order_date = $order->getDate();
        $user_id = $order->getUserId();
        $user_address_id = $order->getAddressId();
        $order_total = $order->getTotal();

        $sql->bind_param("siid",$order_date, $user_id, $user_address_id, $order_total);

        $sql->execute();

        if($sql->affected_rows != 0){
            //echo "Something inserted for a new order";
            //$db->close();
            return $db->insert_id;
        }
        else{
            //$db->close();
            echo "nothing inserted into the database during newOrder";
            return false;
        }
    }

    function addDetailsLine($order_id, $orderDetails){
        $db = db_connect();
        $stmt = $db->prepare("INSERT INTO orderdetails (orders_id, products_id, quantitiy, currentPrice, currentDescription) VALUES (?, ?, ?, ?, ?)");

        if(!$stmt){
            echo "Error in the binding process. SQL error";
            return -1;
        }

        $product_id = $orderDetails->getProductId();
        $quantity = $orderDetails->getQuantity();
        $price = $orderDetails->getCurrentPrice();
        $description = $orderDetails->getCurrentDescription();

        $stmt->bind_param("iiids", $order_id, $product_id, $quantity, $price, $description);

        $stmt->execute();

        if($stmt->affected_rows != 0){
            //success
            return $db->insert_id;
        }
        else{
            //failure
            return -1;
        }
    }

    function getOrdersBetweenDates($date1, $date2){
        $db = db_connect();
        if ($date1 != null && $date2 != null){
            $qry = $db->prepare("SELECT * FROM orders WHERE date > '$date1' AND date < '$date2'");
        }
        else if($date1 != null && $date2 == null){
            $qry = $db->prepare("SELECT * FROM orders WHERE date > '$date1'");
        }
        else if($date1 == null && $date2 != null){
            $qry = $db->prepare("SELECT * FROM orders WHERE date < '$date2'");
        }
        else{
            $qry = $db->prepare("SELECT * FROM orders");
        }

        $qry->execute();
        $subject_set = $qry->get_result();

        if(!$subject_set){
            echo "Database connection Error";
        }

        if($subject_set->num_rows == 0){
            return null;
        }
        else{
            $orders_array = array();
            while($order = $subject_set->fetch_assoc()){
                array_push($orders_array, $order);
            }
            return $orders_array;
        }
    }

    function getProductsOrderedBetweenDates($date1, $date2){

        /*
         * SELECT
         * orderdetails.quantity, orders.date, product.prodID, product.prodName
         * FROM orderdetails
         * JOIN orders ON orders_id = orderdetails.orders_id
         * JOIN product ON prodID = orderdetails.products_id
         */

        $db = db_connect();

        if ($date1 != null && $date2 != null){
            $qry = $db->prepare("SELECT orderdetails.quantity, product.prodID, product.prodName, orderdetails.currentPrice FROM orderdetails JOIN orders ON orders.orders_id = orderdetails.orders_id JOIN product ON prodID = orderdetails.products_id WHERE date > '$date1' AND date < '$date2'");
        }
        else if($date1 != null && $date2 == null){
            $qry = $db->prepare("SELECT orderdetails.quantity, product.prodID, product.prodName, orderdetails.currentPrice FROM orderdetails JOIN orders ON orders.orders_id = orderdetails.orders_id JOIN product ON prodID = orderdetails.products_id WHERE date > '$date1'");
        }
        else if($date1 == null && $date2 != null){
            $qry = $db->prepare("SELECT orderdetails.quantity, product.prodID, product.prodName, orderdetails.currentPrice FROM orderdetails JOIN orders ON orders.orders_id = orderdetails.orders_id JOIN product ON prodID = orderdetails.products_id WHERE date < '$date2'");
        }
        else{
            $qry = $db->prepare("SELECT orderdetails.quantity, product.prodID, product.prodName, orderdetails.currentPrice FROM orderdetails JOIN orders ON orders.orders_id = orderdetails.orders_id JOIN product ON prodID = orderdetails.products_id");
        }

        $qry->execute();
        $subject_set = $qry->get_result();

        if(!$subject_set){
            echo "Database connection Error";
        }

        if($subject_set->num_rows == 0){
            return null;
        }
        else{
            $products_array = array();
            while($product = $subject_set->fetch_assoc()){
                array_push($orders_array, $product);
            }
            return $products_array;
        }
    }

    function getOrderDetails($id){

    }/////////TO-DO

    public function getOrderWithDetails($id){

    }/////////TO-DO
}