<?php
/**
 * Created by PhpStorm.
 * User: tycru
 * Date: 4/26/2019
 * Time: 1:44 PM
 */

require_once('db_credentials.php');

function db_connect(){
    $connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    return $connection;
}

function db_disconnect(){
    if(isset($connection)){
        mysqli_close($connection);
    }
}