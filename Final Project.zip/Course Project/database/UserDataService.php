<?php
/**
 * User:  Tyson Cruz
 * Date:  5/12/2019
 * Class: CST236 - Database Programming II
 * Prof:  Brandon Bass
 */

class UserDataService{

    function findByUserName($username)
    {
        //Return a person that matches the username in the database.
        $db = db_connect();
        $qry = $db->prepare("SELECT * FROM user WHERE username = '$username'");
        $qry->execute();
        $subject_set = $qry->get_result();

        if (!$subject_set) {
            echo "Database connection Error";
        }

        if ($subject_set->num_rows == 0) {
            return null;
        }
        else {
            $person_array = array();
            while ($person = $subject_set->fetch_assoc()) {
                array_push($person_array, $person);
            }
            $user = new user($person_array[0]['idUser'], $person_array[0]['firstname'], $person_array[0]['lastname'], $person_array[0]['username'], $person_array[0]['hashed_password'], $person_array[0]['role']);
            return $user;        }
    }

    function findByFirstName($firstName){
        //Return an array of persons that matches the first name in the database.

        $db = db_connect();
        $qry = $db->prepare("SELECT * FROM user WHERE username = '$firstName'");
        $qry->execute();
        $subject_set = $qry->get_result();

        if (!$subject_set) {
            echo "Database connection Error";
        }

        if ($subject_set->num_rows == 0) {
            return null;
        } else {
            $person_array = array();
            while ($person = $subject_set->fetch_assoc()) {
                array_push($person_array, $person);
            }
            return $person_array;
        }
    }

    function findByLastName($lastName){
        //Return an array of persons that matches the last name in the database.

        $db = db_connect();
        $qry = $db->prepare("SELECT * FROM user WHERE username = '$lastName'");
        $qry->execute();
        $subject_set = $qry->get_result();

        if (!$subject_set) {
            echo "Database connection Error";
        }

        if ($subject_set->num_rows == 0) {
            return null;
        } else {
            $person_array = array();
            while ($person = $subject_set->fetch_assoc()) {
                array_push($person_array, $person);
            }
            return $person_array;
        }
    }

    function findByUserID($id){
        //Return an object of persons that matches the user ID in the database.

        $db = db_connect();
        $qry = $db->prepare("SELECT * FROM user WHERE idUser = '$id'");
        $qry->execute();
        $subject_set = $qry->get_result();

        if (!$subject_set) {
            echo "Database connection Error";
        }

        if ($subject_set->num_rows == 0) {
            return null;
        } else {
            $person_array = array();
            while ($person = $subject_set->fetch_assoc()) {
                array_push($person_array, $person);
            }

            $user = new user($person_array[0]['idUser'], $person_array[0]['firstname'], $person_array[0]['lastname'], $person_array[0]['username'], $person_array[0]['hashed_password'], $person_array[0]['role']);
            return $user;
        }
    }

    function deleteUser($id){
        //Delete a user that matches the user ID in the database.

        $db = db_connect();
        $qry = $db->prepare("DELETE FROM user WHERE idUser = ? LIMIT 1");

        if (!$qry) {
            echo "Database connection Error";
            exit;
        }

        $qry->bind_param("s", $id);
        $qry->execute();

        if($qry->affected_rows == 1){
            return true;
        }else{
            return false;
        }

    }

    function getUserRole($username){
        $db = db_connect();
        $qry = $db->prepare("SELECT idUser FROM user WHERE username = '$username'");
        $qry->execute();
        $subject_set = $qry->get_result();

        if (!$subject_set) {
            echo "Database connection Error";
        }

        $person = $subject_set->fetch_assoc();

        if($person['idUser'] != 0) {
            return true;
        }
        else{
            return false;
        }
    }

    function makeNew($person){

        $db = db_connect();
        $sql = $db->prepare("INSERT INTO user (firstname, lastname, username, hashed_password, role) VALUES (?, ?, ?, ?, ?)");

        if(!$sql){
            echo "Something wrong int he binding process. SQL Error";
            exit;
        }

        $firstname = $person->getFirstName();
        $lastname = $person->getLastName();
        $username = $person->getUsername();
        $role = $person->getRole();
        $encPassword = password_hash($person->getPassword(), PASSWORD_BCRYPT);

        $sql->bind_param("ssssi", $firstname, $lastname, $username, $encPassword, $role);

        $sql->execute();

        if($sql->affected_rows == 1){
            return true;
        }else{
            return false;
        }

    }

    function showAll(){
        //Return an array of persons that shows everyone in the database.

        $db = db_connect();

        $qry = $db ->prepare("SELECT * FROM user");
        $qry->execute();

        $subject_set = $qry->get_result();

        if(!$subject_set){
            echo "Database connection Error";
        }

        if($subject_set->num_rows == 0){
            return null;
        }
        else{
            $person_array = array();
            while($person = $subject_set->fetch_assoc()){
                array_push($person_array, $person);
            }
            return $person_array;
        }
    }

    function updateFirstName($firstname, $id){
        $db = db_connect();
        $qry = $db->prepare("UPDATE user SET firstname = ? WHERE idUser = ? LIMIT 1");

        if (!$qry) {
            echo "Database connection Error";
            exit;
        }

        $qry->bind_param("ss", $firstname, $id);
        $qry->execute();

        if($qry->affected_rows == 1){
            return true;
        }else{
            return false;
        }
    }

    function updateLastName($lastname, $id){
        $db = db_connect();
        $qry = $db->prepare("UPDATE user SET lastname = ? WHERE idUser = ? LIMIT 1");

        if (!$qry) {
            echo "Database connection Error";
            exit;
        }

        $qry->bind_param("ss", $lastname, $id);
        $qry->execute();

        if($qry->affected_rows == 1){
            return true;
        }else{
            return false;
        }
    }

    function updateUsername($username, $id){
        $db = db_connect();
        $qry = $db->prepare("UPDATE user SET username = ? WHERE idUser = ? LIMIT 1");

        if (!$qry) {
            echo "Database connection Error";
            exit;
        }

        $qry->bind_param("ss", $username, $id);
        $qry->execute();

        if($qry->affected_rows == 1){
            return true;
        }else{
            return false;
        }
    }

    function updatePassword($password, $id){
        $db = db_connect();
        $qry = $db->prepare("UPDATE user SET password = ? WHERE idUser = ? LIMIT 1");

        if (!$qry) {
            echo "Database connection Error";
            exit;
        }

        $qry->bind_param("ss", $password, $id);
        $qry->execute();

        if($qry->affected_rows == 1){
            return true;
        }else{
            return false;
        }
    }

    function updateRole($role, $id){
        $db = db_connect();
        $qry = $db->prepare("UPDATE user SET role = ? WHERE idUser = ? LIMIT 1");

        if (!$qry) {
            echo "Database connection Error";
            exit;
        }

        $qry->bind_param("is", $role, $id);
        $qry->execute();

        if($qry->affected_rows == 1){
            return true;
        }else{
            return false;
        }
    }

}