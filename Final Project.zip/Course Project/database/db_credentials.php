<?php
/**
 * Created by PhpStorm.
 * User: tycru
 * Date: 4/26/2019
 * Time: 1:36 PM
 */

define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "password");
define("DB_NAME", "cst236");

