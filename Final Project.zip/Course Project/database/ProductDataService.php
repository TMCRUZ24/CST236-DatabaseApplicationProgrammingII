<?php
/**
 * User:  Tyson Cruz
 * Date:  5/05/2019
 * Class: CST236 - Database Programming II
 * Prof:  Brandon Bass
 */

class ProductDataService{

    function findByProductID($id){///////////////VERIFIED AS RETURNING AN OBJECT, NOT AN ARRAY
        //Return an object of persons that matches the user ID in the database.

        $db = db_connect();
        $qry = $db->prepare("SELECT * FROM product WHERE prodID = '$id'");
        $qry->execute();
        $subject_set = $qry->get_result();

        if (!$subject_set) {
            echo "Database connection Error";
        }

        if ($subject_set->num_rows == 0) {
            return null;
        } else {
            $product_array = array();
            while ($product = $subject_set->fetch_assoc()) {
                array_push($product_array, $product);
            }

            $product = new product($product_array[0]['prodID'], $product_array[0]['prodName'], $product_array[0]['price'], $product_array[0]['description']);
            return $product;
        }
    }

    //function used to find product by name. Queries the database and returns all results that contain
    //that search string. Passes results to __displayProducts() function.
    function findByProductName($productName){

        $db = db_connect();
        if ($productName != null){
        $qry = $db->prepare("SELECT * FROM product WHERE prodName LIKE '%{$productName}%'");
        }
        else{
            $qry = $db->prepare("SELECT * FROM product");
        }

        $qry->execute();
        $subject_set = $qry->get_result();

        if(!$subject_set){
            echo "Database connection Error";
        }

        if($subject_set->num_rows == 0){
            return null;
        }
        else{
            $product_array = array();
            while($product = $subject_set->fetch_assoc()){
                array_push($product_array, $product);
            }
            return $product_array;
        }
    }

    //function used to find product by price. Queries the database and returns all results that contain
    //that search string. Passes results to __displayProducts() function.
    function findByProductPrice($productPrice){

        $db = db_connect();

        $qry = "SELECT * FROM product ";
        $qry .= "WHERE prodName LIKE '%{$productPrice}%'";

        $subject_set = mysqli_query($db, $qry);
        $count = mysqli_num_rows($subject_set);

        if (!$subject_set) {
            echo "Database connection Error";
        }

        $index = 0;
        $users = array();
        while ($row = $subject_set->fetch_assoc()) {
            $users[$index] = array($row["prodName"], $row["price"], $row["description"]);
            ++$index;
        }

        __displayProduct($users, $count);
    }

    function showAll(){
        //Return an array of products that shows all products in the database.

        $db = db_connect();

        $qry = $db ->prepare("SELECT * FROM product");
        $qry->execute();

        $subject_set = $qry->get_result();

        if(!$subject_set){
            echo "Database connection Error";
        }

        if($subject_set->num_rows == 0){
            return null;
        }
        else{
            $product_array = array();
            while($product = $subject_set->fetch_assoc()){
                array_push($product_array, $product);
            }
            return $product_array;
        }
    }

    function makeNew($product){

        $db = db_connect();
        $sql = $db->prepare("INSERT INTO product (prodName, pricee, description) VALUES (?, ?, ?)");

        if(!$sql){
            echo "Something wrong int he binding process. SQL Error";
            exit;
        }

        $name = $product->getProdName();
        $price = $product->getPrice();
        $description = $product->getDescription();

        $sql->bind_param("sds", $name, $price, $description);

        $sql->execute();

        if($sql->affected_rows == 1){
            return true;
        }else{
            return false;
        }
    }

    function deleteProduct($id){
        //Delete a product that matches the product ID in the database.

        $db = db_connect();
        $qry = $db->prepare("DELETE FROM product WHERE prodID = ? LIMIT 1");

        if (!$qry) {
            echo "Database connection Error";
            exit;
        }

        $qry->bind_param("i", $id);
        $qry->execute();

        if($qry->affected_rows == 1){
            return true;
        }else{
            return false;
        }

    }

    function updateProductName($productName, $id){
        $db = db_connect();
        $qry = $db->prepare("UPDATE product SET prodName = ? WHERE prodID = ? LIMIT 1");

        if (!$qry) {
            echo "Database connection Error";
            exit;
        }

        $qry->bind_param("ss", $productName, $id);
        $qry->execute();

        if($qry->affected_rows == 1){
            return true;
        }else{
            return false;
        }
    }

    function updatePrice($price, $id){
        $db = db_connect();
        $qry = $db->prepare("UPDATE product SET price = ? WHERE prodID = ? LIMIT 1");

        if (!$qry) {
            echo "Database connection Error";
            exit;
        }

        $qry->bind_param("ds", $price, $id);
        $qry->execute();

        if($qry->affected_rows == 1){
            return true;
        }else{
            return false;
        }
    }

    function updateDescription($description, $id){
        $db = db_connect();
        $qry = $db->prepare("UPDATE product SET description = ? WHERE prodID = ? LIMIT 1");

        if (!$qry) {
            echo "Database connection Error";
            exit;
        }

        $qry->bind_param("ss", $description, $id);
        $qry->execute();

        if($qry->affected_rows == 1){
            return true;
        }else{
            return false;
        }
    }
}