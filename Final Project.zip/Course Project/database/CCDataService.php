<?php
/**
 * User:  Tyson Cruz
 * Date:  5/17/2019
 * Class: CST236 - Database Programming II
 * Prof:  Brandon Bass
 */

class CCDataService
{

}